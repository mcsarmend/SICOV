@extends('adminlte::auth.passwords.reset')


@section('css')
    <style>
        body {
            background-image: url('/assets/images/login_1.jpg');
            background-size: cover;
            background-position: center;
            opacity: 0.9;
        }

        .login-logo a,
        .register-logo a {
            color: #FFF;
        }
    </style>
@stop
